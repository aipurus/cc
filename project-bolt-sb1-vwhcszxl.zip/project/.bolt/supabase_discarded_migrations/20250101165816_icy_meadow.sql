/*
  # Add payment orders table

  1. New Tables
    - `payment_orders`
      - `id` (uuid, primary key)
      - `order_id` (text, unique) - Razorpay order ID
      - `amount` (integer) - Amount in INR
      - `status` (text) - Payment status
      - `payment_id` (text) - Razorpay payment ID
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `payment_orders` table
    - Add policies for public access to create orders
    - Add policies for authenticated users to update orders
*/

CREATE TABLE IF NOT EXISTS payment_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id text UNIQUE,
  amount integer NOT NULL,
  status text DEFAULT 'pending',
  payment_id text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE payment_orders ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public to create payment orders"
  ON payment_orders
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public to read payment orders"
  ON payment_orders
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow public to update payment orders"
  ON payment_orders
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- Create function to generate order ID
CREATE OR REPLACE FUNCTION generate_order_id()
RETURNS trigger AS $$
BEGIN
  NEW.order_id := 'order_' || substr(md5(random()::text), 1, 16);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-generate order ID
CREATE TRIGGER set_order_id
  BEFORE INSERT ON payment_orders
  FOR EACH ROW
  EXECUTE FUNCTION generate_order_id();

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_payment_orders_updated_at
    BEFORE UPDATE ON payment_orders
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();