/*
  # Setup Storage for Gallery Images

  1. Changes
    - Create storage bucket for gallery images
    - Set up storage policies for public access
*/

-- Create bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('gallery', 'gallery', true)
ON CONFLICT (id) DO NOTHING;

-- Create policies directly on storage.objects
CREATE POLICY "Public Access"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'gallery');

CREATE POLICY "Public Upload"
  ON storage.objects FOR INSERT
  TO public
  WITH CHECK (bucket_id = 'gallery');

CREATE POLICY "Public Update"
  ON storage.objects FOR UPDATE
  TO public
  USING (bucket_id = 'gallery');