/*
  # Update gallery permissions

  1. Changes
    - Allow public users to upload images
    - Remove user_id requirement from gallery_images table
    - Update policies to allow public uploads

  2. Security
    - Enable RLS
    - Add policy for public uploads
*/

-- Remove user_id requirement
ALTER TABLE gallery_images ALTER COLUMN user_id DROP NOT NULL;

-- Update policies
DROP POLICY IF EXISTS "Allow authenticated users to manage gallery images" ON gallery_images;

CREATE POLICY "Allow anyone to upload gallery images"
  ON gallery_images
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow anyone to manage their uploads"
  ON gallery_images
  FOR ALL 
  TO public
  USING (true)
  WITH CHECK (true);