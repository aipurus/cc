/*
  # Add service fee column to pickup_requests table

  1. Changes
    - Add service_fee column if it doesn't exist
    - Set default value of 49
    - Make column non-nullable
  
  2. Notes
    - Uses safe column addition with IF NOT EXISTS
    - Sets default value and NOT NULL constraints
    - Maintains data consistency
*/

DO $$ 
BEGIN
  -- Add service_fee column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'pickup_requests' 
    AND column_name = 'service_fee'
  ) THEN
    ALTER TABLE pickup_requests 
    ADD COLUMN service_fee integer NOT NULL DEFAULT 49;
  END IF;
END $$;