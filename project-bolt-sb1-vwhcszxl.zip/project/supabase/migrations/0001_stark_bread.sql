/*
  # Initial Schema Setup for Community Clothing

  1. New Tables
    - `pickup_requests`
      - `id` (uuid, primary key)
      - `name` (text)
      - `email` (text)
      - `phone` (text)
      - `address` (text)
      - `pickup_date` (date)
      - `items_description` (text)
      - `created_at` (timestamp)
      - `status` (text)
    
    - `gallery_images`
      - `id` (uuid, primary key)
      - `image_url` (text)
      - `caption` (text)
      - `created_at` (timestamp)
      - `user_id` (uuid, references auth.users)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated admin access
    - Add policies for public read access to gallery
*/

-- Create pickup_requests table
CREATE TABLE IF NOT EXISTS pickup_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  pickup_date date NOT NULL,
  items_description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  status text DEFAULT 'pending'
);

-- Create gallery_images table
CREATE TABLE IF NOT EXISTS gallery_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url text NOT NULL,
  caption text,
  created_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users NOT NULL
);

-- Enable RLS
ALTER TABLE pickup_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE gallery_images ENABLE ROW LEVEL SECURITY;

-- Policies for pickup_requests
CREATE POLICY "Allow public to create pickup requests"
  ON pickup_requests
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to view all pickup requests"
  ON pickup_requests
  FOR SELECT
  TO authenticated
  USING (true);

-- Policies for gallery_images
CREATE POLICY "Allow public to view gallery images"
  ON gallery_images
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow authenticated users to manage gallery images"
  ON gallery_images
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);