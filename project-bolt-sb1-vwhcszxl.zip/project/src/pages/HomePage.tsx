import React from 'react';
import { Hero } from '../components/Home/Hero';
import { HowItWorks } from '../components/Home/HowItWorks';
import { Gallery } from '../components/Gallery/Gallery';

export function HomePage() {
  return (
    <div className="bg-neutral-light">
      <Hero />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <HowItWorks />
        <div className="mt-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-primary mb-4">
              Recent Donations
            </h2>
            <p className="text-xl text-neutral-dark">
              See the latest impact of your generosity
            </p>
          </div>
          <Gallery limit={6} />
        </div>
      </div>
    </div>
  );
}