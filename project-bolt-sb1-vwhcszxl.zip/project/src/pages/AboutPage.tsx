import React from 'react';
import { Recycle, Heart, Globe } from 'lucide-react';

interface StatProps {
  value: string;
  label: string;
}

function Stat({ value, label }: StatProps) {
  return (
    <div className="text-center p-6 bg-white/80 backdrop-blur-sm rounded-lg shadow-md animate-scaleIn">
      <div className="text-3xl font-bold text-primary mb-2">{value}</div>
      <div className="text-neutral-dark">{label}</div>
    </div>
  );
}

export function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary-light to-neutral-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16 animate-fadeIn">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6">Our Mission</h1>
          <p className="text-xl text-neutral-dark max-w-3xl mx-auto">
            At Community Clothing, we believe in the power of sustainable fashion to create positive change. 
            Our mission is to reduce textile waste while helping those in need, creating a more sustainable 
            and compassionate community.
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Stat value="10,000+" label="Items Donated" />
          <Stat value="500+" label="Families Helped" />
          <Stat value="5,000kg" label="Textile Waste Saved" />
        </div>

        {/* Values Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="text-center p-6 transform transition-all duration-500 hover:scale-105 animate-scaleIn">
            <div className="bg-secondary-light w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 animate-float">
              <Recycle className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-primary mb-2">Sustainability</h3>
            <p className="text-neutral-dark">
              We're committed to reducing textile waste and promoting sustainable fashion practices 
              in our community.
            </p>
          </div>

          <div className="text-center p-6 transform transition-all duration-500 hover:scale-105 animate-scaleIn" style={{ animationDelay: '150ms' }}>
            <div className="bg-secondary-light w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 animate-float">
              <Heart className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-primary mb-2">Community</h3>
            <p className="text-neutral-dark">
              We believe in the power of community to create positive change through shared resources 
              and mutual support.
            </p>
          </div>

          <div className="text-center p-6 transform transition-all duration-500 hover:scale-105 animate-scaleIn" style={{ animationDelay: '300ms' }}>
            <div className="bg-secondary-light w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 animate-float">
              <Globe className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-primary mb-2">Impact</h3>
            <p className="text-neutral-dark">
              Every donation makes a difference, contributing to both environmental sustainability 
              and community welfare.
            </p>
          </div>
        </div>

        {/* Story Section */}
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-8 shadow-lg animate-fadeIn">
          <h2 className="text-3xl font-bold text-primary mb-6 text-center">Our Story</h2>
          <div className="max-w-3xl mx-auto text-neutral-dark space-y-4">
            <p>
              Founded with a vision to make sustainable fashion accessible to all, Community Clothing 
              has grown from a small neighborhood initiative into a thriving platform for clothing 
              donation and redistribution.
            </p>
            <p>
              We work closely with local organizations to ensure that your donations reach those who 
              need them most, while simultaneously reducing the environmental impact of textile waste 
              in our landfills.
            </p>
            <p>
              Through our work, we helping countless families access quality clothing while preventing 
              thousands of garments from ending up in landfills. Every donation contributes to our 
              dual mission of environmental sustainability and community support.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}