import React from 'react';
import { Gallery } from '../components/Gallery/Gallery';

export function GalleryPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary-light to-neutral-light py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-primary mb-8 text-center">Gallery</h1>
        <Gallery />
      </div>
    </div>
  );
}