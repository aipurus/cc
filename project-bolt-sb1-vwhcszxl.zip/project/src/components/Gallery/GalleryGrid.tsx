import React from 'react';
import { Camera } from 'lucide-react';

interface GalleryImage {
  id: string;
  image_url: string;
  caption: string;
  created_at: string;
}

interface GalleryGridProps {
  images: GalleryImage[];
}

export function GalleryGrid({ images }: GalleryGridProps) {
  if (images.length === 0) {
    return (
      <div className="text-center py-12 animate-fadeIn">
        <Camera className="mx-auto h-12 w-12 text-primary animate-float" />
        <h3 className="mt-2 text-sm font-medium text-neutral-dark">No images yet</h3>
        <p className="mt-1 text-sm text-neutral-dark/70">
          Images will appear here once uploaded
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 xs:grid-cols-3 gap-4 md:gap-6">
      {images.map((image, index) => (
        <div
          key={image.id}
          className="group relative aspect-square overflow-hidden rounded-2xl bg-white shadow-md hover:shadow-xl transition-all duration-500 animate-scaleIn"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <img
            src={image.image_url}
            alt={image.caption || 'Donation'}
            className="w-full h-full object-cover transform transition-all duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300">
            <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
              <p className="text-sm font-medium text-white line-clamp-2">
                {image.caption || 'Making a difference'}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}