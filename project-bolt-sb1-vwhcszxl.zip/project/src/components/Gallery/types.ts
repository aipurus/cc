export interface GalleryImage {
  id: string;
  image_url: string;
  caption: string;
  created_at: string;
}