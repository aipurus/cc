import type { GalleryImage } from './types';

// Empty demo images array since we don't want demo images anymore
export const DEMO_IMAGES: GalleryImage[] = [];