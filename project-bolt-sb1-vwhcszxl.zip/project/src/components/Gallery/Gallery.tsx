import React from 'react';
import { GalleryGrid } from './GalleryGrid';
import { useGalleryImages } from './hooks/useGalleryImages';

interface GalleryProps {
  limit?: number;
}

export function Gallery({ limit }: GalleryProps) {
  const { images, loading, error } = useGalleryImages(limit);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse">
          <GalleryGrid images={[]} />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {error && (
        <div className="mb-4 p-4 bg-red-50 text-red-700 rounded-lg">
          {error}
        </div>
      )}
      <GalleryGrid images={images} />
    </div>
  );
}