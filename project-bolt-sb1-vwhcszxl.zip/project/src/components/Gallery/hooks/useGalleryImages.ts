import { useState, useEffect } from 'react';
import { supabase } from '../../../lib/supabase/client';
import { handleSupabaseError } from '../../../lib/supabase/errors';
import { DEMO_IMAGES } from '../constants';
import type { GalleryImage } from '../types';

export function useGalleryImages(limit?: number) {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);
  const MAX_RETRIES = 3;

  useEffect(() => {
    let mounted = true;
    let timeoutId: number;

    const fetchImages = async () => {
      if (!mounted) return;

      try {
        setLoading(true);
        setError(null);

        let query = supabase
          .from('gallery_images')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (limit) {
          query = query.limit(limit);
        }

        const { data, error: supabaseError } = await query;

        if (!mounted) return;

        if (supabaseError) {
          throw supabaseError;
        }

        setImages(data || []);
        setRetryCount(0); // Reset retry count on success
      } catch (error) {
        if (!mounted) return;

        const appError = handleSupabaseError(error as Error);
        setError(appError.message);

        // Implement retry logic
        if (retryCount < MAX_RETRIES) {
          setRetryCount(prev => prev + 1);
          timeoutId = window.setTimeout(() => {
            if (mounted) {
              fetchImages();
            }
          }, Math.min(1000 * Math.pow(2, retryCount), 8000)); // Exponential backoff
        } else {
          // Fallback to demo images after max retries
          setImages(DEMO_IMAGES.map((url, index) => ({
            id: `demo-${index}`,
            image_url: url,
            caption: 'Demo Image',
            created_at: new Date().toISOString()
          })));
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    fetchImages();

    return () => {
      mounted = false;
      if (timeoutId) {
        window.clearTimeout(timeoutId);
      }
    };
  }, [limit, retryCount]);

  return { images, loading, error };
}