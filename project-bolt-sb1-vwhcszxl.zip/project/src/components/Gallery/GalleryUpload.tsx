import React, { useState } from 'react';
import { Upload, Loader, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface GalleryUploadProps {
  onUploadComplete: () => void;
}

export function GalleryUpload({ onUploadComplete }: GalleryUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);

    try {
      if (!file.type.startsWith('image/')) {
        throw new Error('Please upload an image file');
      }

      if (file.size > 5 * 1024 * 1024) {
        throw new Error('Image size should be less than 5MB');
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `gallery/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('gallery')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('gallery')
        .getPublicUrl(filePath);

      const { error: dbError } = await supabase
        .from('gallery_images')
        .insert([{
          image_url: publicUrl,
          caption: file.name.split('.')[0]
        }]);

      if (dbError) throw dbError;

      onUploadComplete();
    } catch (err: any) {
      setError(err.message);
      console.error('Upload error:', err);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="mb-8">
      <label className="inline-block">
        <div
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-300
            ${uploading 
              ? 'bg-neutral-light text-primary cursor-not-allowed' 
              : 'bg-primary text-white hover:bg-primary-dark cursor-pointer hover:shadow-lg hover:-translate-y-0.5'
            }`}
        >
          {uploading ? (
            <>
              <Loader className="w-5 h-5 animate-spin" />
              <span>Uploading...</span>
            </>
          ) : (
            <>
              <Upload className="w-5 h-5" />
              <span>Upload Image</span>
            </>
          )}
        </div>
        <input
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          disabled={uploading}
          className="hidden"
        />
      </label>

      {error && (
        <div className="mt-2 text-red-600 flex items-center gap-1 text-sm">
          <AlertCircle className="w-4 h-4" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
}