import React from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Navbar';
import { Footer } from './Footer/Footer';
import { NotificationBanner } from './Notification/NotificationBanner';

export function Layout() {
  return (
    <div className="min-h-screen bg-neutral-light flex flex-col">
      <NotificationBanner />
      <Navbar />
      <main className="flex-grow">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}