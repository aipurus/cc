import React from 'react';
import { MapPin } from 'lucide-react';

export function NotificationBanner() {
  return (
    <div className="bg-primary text-white py-2 text-center relative z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center gap-2 text-sm sm:text-base">
          <MapPin className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
          <span>We are currently serving in Delhi NCR Region only</span>
        </div>
      </div>
    </div>
  );
}