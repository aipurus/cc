import React from 'react';
import { Instagram, Facebook, Twitter, Youtube, Linkedin } from 'lucide-react';
import { FooterLink } from './FooterLink';

export function SocialLinks() {
  const socialLinks = [
    { icon: Instagram, url: 'https://instagram.com/communityclothing' },
    { icon: Facebook, url: 'https://facebook.com/communityclothing' },
    { icon: Twitter, url: 'https://twitter.com/communitycloth' },
    { icon: Youtube, url: 'https://youtube.com/communityclothing' },
    { icon: Linkedin, url: 'https://linkedin.com/company/communityclothing' }
  ];

  return (
    <div className="flex flex-wrap gap-4">
      {socialLinks.map(({ icon: Icon, url }) => (
        <FooterLink key={url} to={url} external>
          <Icon className="w-6 h-6 hover:scale-110 transition-transform" />
        </FooterLink>
      ))}
    </div>
  );
}