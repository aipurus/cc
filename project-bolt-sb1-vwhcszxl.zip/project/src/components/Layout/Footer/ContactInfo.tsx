import React from 'react';
import { Mail, Phone, MapPin, Clock } from 'lucide-react';

export function ContactInfo() {
  return (
    <div className="space-y-3">
      <div className="flex items-center space-x-2 text-secondary-light group">
        <Mail className="w-5 h-5 flex-shrink-0 group-hover:text-white transition-colors" />
        <a 
          href="mailto:communityclothing.in@gmail.com" 
          className="hover:text-white transition-colors break-all"
        >
          communityclothing.in@gmail.com
        </a>
      </div>
      <div className="flex items-center space-x-2 text-secondary-light group">
        <Phone className="w-5 h-5 flex-shrink-0 group-hover:text-white transition-colors" />
        <a 
          href="tel:+15551234567" 
          className="hover:text-white transition-colors"
        >
          +1 (555) 123-4567
        </a>
      </div>
      <div className="flex items-start space-x-2 text-secondary-light group">
        <MapPin className="w-5 h-5 flex-shrink-0 mt-1 group-hover:text-white transition-colors" />
        <span className="hover:text-white transition-colors">
          123 Community Ave,<br />
          City, State 12345
        </span>
      </div>
      <div className="flex items-center space-x-2 text-secondary-light group">
        <Clock className="w-5 h-5 flex-shrink-0 group-hover:text-white transition-colors" />
        <span className="hover:text-white transition-colors">
          Mon-Fri: 9AM-6PM
        </span>
      </div>
    </div>
  );
}