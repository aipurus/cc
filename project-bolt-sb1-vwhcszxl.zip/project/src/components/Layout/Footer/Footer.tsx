import React from 'react';
import { Heart } from 'lucide-react';
import { FooterSection } from './FooterSection';
import { FooterLink } from './FooterLink';
import { SocialLinks } from './SocialLinks';
import { ContactInfo } from './ContactInfo';

export function Footer() {
  return (
    <footer className="bg-primary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Newsletter Section */}
        <div className="py-8 border-b border-primary-dark">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-bold text-white mb-4">Join Our Newsletter</h2>
            <p className="text-secondary-light mb-6">
              Stay updated with our latest initiatives and community events
            </p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-grow px-4 py-2 rounded-lg bg-white/10 border border-primary-dark 
                  text-white placeholder:text-secondary-light focus:outline-none focus:ring-2 
                  focus:ring-secondary-light"
              />
              <button
                type="submit"
                className="px-6 py-2 bg-secondary-light text-primary font-medium rounded-lg
                  hover:bg-white transition-colors duration-300"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 py-12">
          {/* About Section */}
          <FooterSection title="About Us">
            <p className="text-secondary-light">
              Community Clothing is dedicated to making a positive impact through sustainable 
              fashion and community support. Together, we're building a more sustainable future.
            </p>
            <div className="flex items-center space-x-2 text-secondary-light mt-4">
              <Heart className="w-5 h-5" />
              <span>Making a difference together</span>
            </div>
          </FooterSection>

          {/* Quick Links */}
          <FooterSection title="Quick Links">
            <div className="grid grid-cols-2 gap-2">
              <FooterLink to="/">Home</FooterLink>
              <FooterLink to="/about">About</FooterLink>
              <FooterLink to="/donate">Donate</FooterLink>
              <FooterLink to="/gallery">Gallery</FooterLink>
              <FooterLink to="/faq">FAQ</FooterLink>
              <FooterLink to="/impact">Our Impact</FooterLink>
            </div>
          </FooterSection>

          {/* Contact Info */}
          <FooterSection title="Contact Us">
            <ContactInfo />
          </FooterSection>

          {/* Social Links */}
          <FooterSection title="Connect With Us">
            <p className="text-secondary-light mb-4">
              Follow us on social media for updates and inspiration
            </p>
            <SocialLinks />
          </FooterSection>
        </div>

        {/* Copyright Bar */}
        <div className="border-t border-primary-dark py-6">
          <div className="text-center text-secondary-light">
            <p>© {new Date().getFullYear()} Community Clothing. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}