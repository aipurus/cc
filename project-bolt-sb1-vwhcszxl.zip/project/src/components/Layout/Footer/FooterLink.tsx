import React from 'react';
import { Link } from 'react-router-dom';

interface FooterLinkProps {
  to: string;
  children: React.ReactNode;
  external?: boolean;
}

export function FooterLink({ to, children, external }: FooterLinkProps) {
  if (external) {
    return (
      <a 
        href={to}
        target="_blank"
        rel="noopener noreferrer"
        className="block text-secondary-light hover:text-white transition-colors"
      >
        {children}
      </a>
    );
  }
  
  return (
    <Link 
      to={to}
      className="block text-secondary-light hover:text-white transition-colors"
    >
      {children}
    </Link>
  );
}