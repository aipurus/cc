import React from 'react';
import { Link } from 'react-router-dom';

export function Hero() {
  return (
    <div className="relative">
      <img
        src="https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80"
        alt="Clothing rack"
        className="w-full h-[50vh] md:h-[60vh] object-cover transition-transform duration-700 hover:scale-105"
      />
      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <div className="text-center text-white px-4 animate-fadeIn max-w-4xl mx-auto">
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
            Your Old Clothes, Their New Hope
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
            Join us in making a difference through clothing donation
          </p>
          <Link
            to="/donate"
            className="bg-primary hover:bg-primary-dark text-white px-6 sm:px-8 py-2 sm:py-3 rounded-full 
              text-base sm:text-lg font-medium inline-block transition-all duration-300 
              hover:shadow-lg hover:-translate-y-1"
          >
            Donate Now
          </Link>
        </div>
      </div>
    </div>
  );
}