import React from 'react';
import { LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  delay: string;
}

export function FeatureCard({ icon: Icon, title, description, delay }: FeatureCardProps) {
  return (
    <div 
      className="text-center transform transition-all duration-500 hover:scale-105 animate-scaleIn"
      style={{ animationDelay: delay }}
    >
      <div className="bg-secondary-light w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 animate-float">
        <Icon className="w-8 h-8 text-primary" />
      </div>
      <h3 className="text-xl font-semibold text-primary mb-2">{title}</h3>
      <p className="text-neutral-dark">{description}</p>
    </div>
  );
}