import React from 'react';
import { Heart, Truck, Camera } from 'lucide-react';
import { FeatureCard } from './FeatureCard';

const features = [
  {
    icon: Heart,
    title: 'Choose Items',
    description: 'Select gently used clothing items you\'d like to donate',
    delay: '0ms'
  },
  {
    icon: Truck,
    title: 'Schedule Pickup',
    description: 'Book a convenient time for us to collect your donations',
    delay: '150ms'
  },
  {
    icon: Camera,
    title: 'Share Impact',
    description: 'See your donations in our gallery making a difference',
    delay: '300ms'
  }
];

export function HowItWorks() {
  return (
    <>
      <div className="text-center mb-12 lg:mb-16 animate-fadeIn px-4">
        <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-4">
          How It Works
        </h2>
        <p className="text-lg sm:text-xl text-neutral-dark max-w-2xl mx-auto">
          Making a difference is as easy as 1-2-3
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12 px-4 sm:px-6">
        {features.map((feature, index) => (
          <FeatureCard key={index} {...feature} />
        ))}
      </div>
    </>
  );
}