import React from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Layout/Navbar';
import { Footer } from './Layout/Footer';

export function Layout() {
  return (
    <div className="min-h-screen bg-neutral-light">
      <Navbar />
      <main>
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}