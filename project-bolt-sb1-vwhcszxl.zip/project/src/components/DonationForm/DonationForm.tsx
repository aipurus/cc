import React from 'react';
import { Package } from 'lucide-react';
import { FormInput } from './FormInput';
import { SuccessMessage } from './SuccessMessage';
import { InfoCards } from './InfoCards';
import { useDonationForm } from './hooks/useDonationForm';

export function DonationForm() {
  const {
    formData,
    loading,
    success,
    error,
    handleChange,
    handleSubmit
  } = useDonationForm();

  if (success) {
    return <SuccessMessage />;
  }

  return (
    <div className="w-full max-w-2xl mx-auto animate-fadeIn px-4 sm:px-6">
      <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-4 sm:p-6 md:p-8 transition-transform duration-300 hover:shadow-xl">
        {/* Service Fee Notice */}
        <div className="mb-6 p-4 bg-primary/5 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-neutral-dark font-medium">Service Fee</span>
            <span className="font-semibold text-primary">₹49</span>
          </div>
          <p className="text-sm text-neutral-dark/80">
            A nominal service fee of ₹49 will be collected during pickup to support our operations and maintain service quality.
          </p>
        </div>
        
        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            <FormInput
              label="Name"
              name="name"
              type="text"
              required
              value={formData.name}
              onChange={handleChange}
              placeholder="Your full name"
            />

            <FormInput
              label="Email"
              name="email"
              type="email"
              required
              value={formData.email}
              onChange={handleChange}
              placeholder="your@email.com"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            <FormInput
              label="Phone"
              name="phone"
              type="tel"
              required
              value={formData.phone}
              onChange={handleChange}
              placeholder="Your phone number"
            />

            <FormInput
              label="Pickup Date"
              name="pickup_date"
              type="date"
              required
              value={formData.pickup_date}
              onChange={handleChange}
              min={new Date().toISOString().split('T')[0]}
            />
          </div>

          <FormInput
            label="Address"
            name="address"
            type="text"
            required
            value={formData.address}
            onChange={handleChange}
            placeholder="Pickup address"
          />

          <FormInput
            label="Items Description"
            name="items_description"
            required
            value={formData.items_description}
            onChange={handleChange}
            placeholder="Please describe the items you're donating..."
            textarea
            rows={4}
          />

          <div className="pt-4">
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-lg
                font-medium transition-all duration-300 hover:shadow-lg hover:-translate-y-1
                flex items-center justify-center space-x-2 text-base sm:text-lg disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Package className="w-5 h-5 animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <span>Schedule Pickup</span>
              )}
            </button>
          </div>
        </form>
      </div>

      <InfoCards />
    </div>
  );
}