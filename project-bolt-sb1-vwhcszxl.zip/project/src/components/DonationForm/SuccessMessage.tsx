import React from 'react';
import { Send } from 'lucide-react';

export function SuccessMessage() {
  return (
    <div className="max-w-md mx-auto bg-accent/50 border border-primary-light rounded-xl p-8 text-center">
      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
        <Send className="w-8 h-8 text-primary" />
      </div>
      <h3 className="text-xl font-semibold text-primary mb-2">Thank You!</h3>
      <p className="text-text">
        Your pickup request has been scheduled. We'll contact you soon to confirm the details.
      </p>
    </div>
  );
}