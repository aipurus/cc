import React from 'react';

interface FormInputProps extends React.InputHTMLAttributes<HTMLInputElement | HTMLTextAreaElement> {
  label: string;
  error?: string;
  textarea?: boolean;
}

export function FormInput({ label, error, textarea, className = '', ...props }: FormInputProps) {
  const Component = textarea ? 'textarea' : 'input';
  
  return (
    <div className="mb-4">
      <label className="block text-sm font-medium text-text mb-1">
        {label}
      </label>
      <Component
        {...props}
        className={`w-full px-3 py-2 border border-primary-light rounded-lg shadow-sm 
          focus:ring-2 focus:ring-primary focus:border-transparent
          bg-secondary backdrop-blur-sm
          placeholder:text-primary/60
          ${error ? 'border-red-500' : ''}
          ${className}`}
      />
      {error && (
        <p className="mt-1 text-sm text-red-600">{error}</p>
      )}
    </div>
  );
}