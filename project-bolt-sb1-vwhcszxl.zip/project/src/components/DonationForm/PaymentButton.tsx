import React from 'react';
import { IndianRupee } from 'lucide-react';
import { initializeRazorpay, createPaymentOrder, handlePayment } from '../../lib/payment/razorpay';

interface PaymentButtonProps {
  name: string;
  email: string;
  phone: string;
  onSuccess: () => void;
  onError: (error: Error) => void;
}

export function PaymentButton({ 
  name, 
  email, 
  phone, 
  onSuccess, 
  onError 
}: PaymentButtonProps) {
  const handleClick = async () => {
    try {
      const isRazorpayLoaded = await initializeRazorpay();
      
      if (!isRazorpayLoaded) {
        throw new Error('Razorpay SDK failed to load');
      }

      const orderId = await createPaymentOrder(49);
      
      await handlePayment({
        orderId,
        amount: 49,
        currency: 'INR',
        name,
        email,
        phone
      });

      onSuccess();
    } catch (error) {
      onError(error as Error);
    }
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className="w-full bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-lg
        font-medium transition-all duration-300 hover:shadow-lg hover:-translate-y-1
        flex items-center justify-center space-x-2 text-base sm:text-lg"
    >
      <IndianRupee className="w-5 h-5" />
      <span>Pay ₹49 & Schedule Pickup</span>
    </button>
  );
}