import React from 'react';
import { Calendar, MapPin, Package } from 'lucide-react';

export function InfoCards() {
  return (
    <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-secondary backdrop-blur-sm rounded-lg p-4 text-center">
        <Calendar className="w-8 h-8 text-primary mx-auto mb-2" />
        <h3 className="font-medium text-text">Flexible Scheduling</h3>
        <p className="text-sm text-primary">Choose a pickup time that works for you</p>
      </div>

      <div className="bg-secondary backdrop-blur-sm rounded-lg p-4 text-center">
        <MapPin className="w-8 h-8 text-primary mx-auto mb-2" />
        <h3 className="font-medium text-text">Free Pickup</h3>
        <p className="text-sm text-primary">We'll come to your location</p>
      </div>

      <div className="bg-secondary backdrop-blur-sm rounded-lg p-4 text-center">
        <Package className="w-8 h-8 text-primary mx-auto mb-2" />
        <h3 className="font-medium text-text">Any Amount</h3>
        <p className="text-sm text-primary">Big or small, every donation helps</p>
      </div>
    </div>
  );
}