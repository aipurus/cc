import { useState } from 'react';
import { supabase } from '../../../lib/supabase/client';

interface FormData {
  name: string;
  email: string;
  phone: string;
  address: string;
  pickup_date: string;
  items_description: string;
}

const initialFormData: FormData = {
  name: '',
  email: '',
  phone: '',
  address: '',
  pickup_date: '',
  items_description: ''
};

export function useDonationForm() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const { error: submitError } = await supabase
        .from('pickup_requests')
        .insert([formData]); // Service fee is handled by the default value in the database

      if (submitError) throw submitError;
      
      setSuccess(true);
      setFormData(initialFormData);
    } catch (error) {
      console.error('Error:', error);
      setError('Failed to schedule pickup. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return {
    formData,
    loading,
    success,
    error,
    handleChange,
    handleSubmit
  };
}