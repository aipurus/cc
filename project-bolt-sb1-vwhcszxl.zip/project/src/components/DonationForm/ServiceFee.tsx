import React from 'react';
import { IndianRupee } from 'lucide-react';

export function ServiceFee() {
  return (
    <div className="flex items-center justify-between p-4 bg-primary/5 rounded-lg mb-6">
      <div className="flex items-center gap-2">
        <IndianRupee className="w-5 h-5 text-primary" />
        <span className="text-neutral-dark">Pickup Service Fee</span>
      </div>
      <span className="font-semibold text-primary">₹49</span>
    </div>
  );
}