import React from 'react';
import { COLORS } from '../../lib/constants';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary';
  children: React.ReactNode;
}

export function Button({ variant = 'primary', children, className = '', ...props }: ButtonProps) {
  const baseStyles = 'px-4 py-2 rounded-md transition-all duration-200 font-medium';
  const variants = {
    primary: `bg-[${COLORS.primary}] hover:bg-opacity-90 text-white`,
    secondary: `bg-[${COLORS.white}] hover:bg-opacity-90 text-[${COLORS.text}] border border-[${COLORS.border}]`
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}