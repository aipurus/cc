import React, { useEffect, useState } from 'react';
import { Camera, Upload, Loader } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface GalleryImage {
  id: string;
  image_url: string;
  caption: string;
  created_at: string;
}

const DEMO_IMAGES = [
  'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1562157873-818bc0726f68?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
];

export function Gallery() {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [session, setSession] = useState<any>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchImages();
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });
  }, []);

  const fetchImages = async () => {
    const { data, error } = await supabase
      .from('gallery_images')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching images:', error);
      return;
    }

    setImages(data || []);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;

    const file = e.target.files[0];
    setUploading(true);

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `gallery/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('gallery')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('gallery')
        .getPublicUrl(filePath);

      const { error: dbError } = await supabase
        .from('gallery_images')
        .insert([
          {
            image_url: publicUrl,
            caption: '',
            user_id: session?.user?.id
          }
        ]);

      if (dbError) throw dbError;

      fetchImages();
    } catch (error) {
      console.error('Error uploading image:', error);
      alert('Error uploading image. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const displayImages = images.length > 0 ? images : DEMO_IMAGES.map((url, index) => ({
    id: `demo-${index}`,
    image_url: url,
    caption: 'Demo Image',
    created_at: new Date().toISOString()
  }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        {session && (
          <label className="cursor-pointer bg-amber-700 hover:bg-amber-800 text-white px-4 py-2 rounded-md flex items-center space-x-2 transition-colors">
            {uploading ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                <span>Uploading...</span>
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                <span>Upload Image</span>
              </>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              disabled={uploading}
              className="hidden"
            />
          </label>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {displayImages.map((image) => (
          <div
            key={image.id}
            className="group relative aspect-square overflow-hidden rounded-lg shadow-lg bg-white"
          >
            <img
              src={image.image_url}
              alt={image.caption || 'Donation'}
              className="w-full h-full object-cover transform transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                <p className="text-sm font-medium">{image.caption || 'Making a difference'}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {displayImages.length === 0 && (
        <div className="text-center py-12">
          <Camera className="mx-auto h-12 w-12 text-amber-400" />
          <h3 className="mt-2 text-sm font-medium text-amber-900">No images</h3>
          <p className="mt-1 text-sm text-amber-700">
            Start by uploading your first image to the gallery.
          </p>
        </div>
      )}
    </div>
  );
}