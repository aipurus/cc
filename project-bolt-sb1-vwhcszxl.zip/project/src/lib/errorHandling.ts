import { PostgrestError } from '@supabase/supabase-js';

export function handleSupabaseError(error: PostgrestError): void {
  // Log the error for debugging but don't expose details to users
  console.error('Supabase error:', error);
  
  // In production, you might want to send this to an error tracking service
  if (process.env.NODE_ENV === 'production') {
    // Send to error tracking service
  }
}