import { supabase } from '../supabase/client';

declare global {
  interface Window {
    Razorpay: any;
  }
}

export interface PaymentDetails {
  orderId: string;
  amount: number;
  currency: string;
  name: string;
  email: string;
  phone: string;
}

export async function initializeRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export async function createPaymentOrder(amount: number): Promise<string> {
  try {
    const { data, error } = await supabase
      .from('payment_orders')
      .insert([{ amount }])
      .select('order_id')
      .single();

    if (error) throw error;
    return data.order_id;
  } catch (error) {
    console.error('Error creating payment order:', error);
    throw new Error('Failed to create payment order');
  }
}

export function handlePayment(details: PaymentDetails): Promise<boolean> {
  return new Promise((resolve, reject) => {
    const options = {
      key: import.meta.env.VITE_RAZORPAY_KEY_ID,
      amount: details.amount * 100, // Razorpay expects amount in paise
      currency: details.currency,
      name: 'Community Clothing',
      description: 'Pickup Service Fee',
      order_id: details.orderId,
      prefill: {
        name: details.name,
        email: details.email,
        contact: details.phone,
      },
      handler: async (response: any) => {
        try {
          const { error } = await supabase
            .from('payment_orders')
            .update({ 
              payment_id: response.razorpay_payment_id,
              status: 'completed'
            })
            .eq('order_id', details.orderId);

          if (error) throw error;
          resolve(true);
        } catch (error) {
          console.error('Error updating payment status:', error);
          reject(error);
        }
      },
      modal: {
        ondismiss: () => {
          reject(new Error('Payment cancelled'));
        }
      }
    };

    const razorpay = new window.Razorpay(options);
    razorpay.open();
  });
}