export const ADMIN_EMAIL = 'igprinceraj2@gmail.com';
export const COLORS = {
  primary: '#7D5A50',
  white: 'rgba(255, 255, 255, 0.8)',
  text: '#392F2D',
  border: '#B4846C',
  accent: '#FAECD6'
} as const;