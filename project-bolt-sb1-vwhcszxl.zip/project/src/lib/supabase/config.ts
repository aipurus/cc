// Supabase configuration constants
export const SUPABASE_CONFIG = {
  url: import.meta.env.VITE_SUPABASE_URL,
  anonKey: import.meta.env.VITE_SUPABASE_ANON_KEY,
  // Add timeouts and retries for better reliability
  timeout: 10000,
  retryAttempts: 3,
  retryDelay: 1000,
} as const;