import { PostgrestError } from '@supabase/supabase-js';

export enum ErrorType {
  NETWORK = 'NETWORK',
  DATABASE = 'DATABASE',
  AUTH = 'AUTH',
  UNKNOWN = 'UNKNOWN',
}

export interface AppError {
  type: ErrorType;
  message: string;
  originalError?: unknown;
}

export function handleSupabaseError(error: PostgrestError | Error): AppError {
  if ('code' in error) {
    // Handle Postgrest errors
    return {
      type: ErrorType.DATABASE,
      message: 'Database operation failed. Please try again later.',
      originalError: error,
    };
  }

  if (error.message.includes('fetch')) {
    return {
      type: ErrorType.NETWORK,
      message: 'Network connection failed. Please check your internet connection.',
      originalError: error,
    };
  }

  return {
    type: ErrorType.UNKNOWN,
    message: 'An unexpected error occurred. Please try again.',
    originalError: error,
  };
}