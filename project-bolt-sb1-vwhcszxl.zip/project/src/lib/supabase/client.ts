import { createClient } from '@supabase/supabase-js';
import { SUPABASE_CONFIG } from './config';
import type { Database } from '../database.types';

// Create Supabase client with configuration
export const supabase = createClient<Database>(
  SUPABASE_CONFIG.url,
  SUPABASE_CONFIG.anonKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
    global: {
      headers: {
        'x-client-info': 'community-clothing'
      },
      fetch: async (...args) => {
        try {
          const response = await fetch(...args);
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
          return response;
        } catch (err) {
          if (err instanceof Error && err.name === 'AbortError') {
            // Ignore abort errors as they're intentional
            throw err;
          }
          console.error('Network error:', err);
          throw new Error('Unable to connect to the server. Please check your internet connection and try again.');
        }
      },
    },
    db: {
      schema: 'public'
    },
    realtime: {
      params: {
        eventsPerSecond: 10
      }
    }
  }
);