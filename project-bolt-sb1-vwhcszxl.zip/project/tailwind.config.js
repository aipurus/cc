/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      screens: {
        'xs': '475px',
      },
      colors: {
        primary: {
          light: '#B4846C',  // Warm taupe
          DEFAULT: '#7D5A50', // Rich mocha
          dark: '#5C4033',   // Deep coffee
        },
        secondary: {
          light: '#FAECD6',  // Soft cream
          DEFAULT: '#E7BC91', // Warm sand
          dark: '#B4846C',   // Muted copper
        },
        neutral: {
          light: '#FDF5E6',  // Antique white
          DEFAULT: '#FAF0E6', // Linen
          dark: '#392F2D',   // Deep brown
        }
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' }
        },
        slideIn: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(0)' }
        },
        scaleIn: {
          '0%': { transform: 'scale(0.9)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' }
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' }
        }
      },
      animation: {
        fadeIn: 'fadeIn 0.5s ease-out',
        slideIn: 'slideIn 0.6s ease-out',
        scaleIn: 'scaleIn 0.5s ease-out',
        float: 'float 3s ease-in-out infinite'
      }
    },
  },
  plugins: [],
};